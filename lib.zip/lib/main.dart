import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

// Color(0xFF123524), // Phthalo Green
// Color.fromARGB(255, 14, 19, 17), // Lighter Green
// Half White Color(0xFF5F5F5)

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PlantPal',
      home: LandingPage(),
    );
  }
}

class LandingPage extends StatelessWidget {
  const LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage('../assets/home_screen_bg_plant.jpg'),
            opacity: 0.6,
            fit: BoxFit.cover),
      ),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: 50),
            Icon(Icons.forest),
            Text(
              'PlantPal',
              style: TextStyle(
                  color: Color(0xFF123524),
                  fontSize: 48,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 40),
            Text(
              "Taking Care Of Your Plant Is Essential For\nThem To Grow and Have a Healtheir Longer Lifespan.\nPlantPal will Assist You By Reminding You To Water\nYour Plants on Regular Basis, Lookup for Harmful\nWeed Growing Around and much more.",
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF123524),
                  fontSize: 14),
            ),
            SizedBox(height: 80),
            ElevatedButton(
              child: Text('Sign In'),
              onPressed: () {
                print("Login!");
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF123524),
                  foregroundColor: Color(0xFFF5F5F5)),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Sign Up'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFF5F5F5),
                  foregroundColor: Color(0xFF123524)),
              onPressed: () {},
            ),
          ],
        ),
      ),
    ));
  }
}
